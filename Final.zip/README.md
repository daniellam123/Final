Submitted by: Daniel Lam (directory id: dlam123)  
Group Members: Daniel Lam (dlam123)  
App Description: Allows users to generate quotes and stores history of quotes  
YouTube Video Link: [https://youtu.be/CdgrCto7izY?feature=shared](https://youtu.be/CdgrCto7izY?feature=shared)  
APIs: Quotes88 [https://quotes88.p.rapidapi.com/](https://quotes88.p.rapidapi.com/)  
Contact Email: dlam123@terpmail.umd.edu  